package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddEmployeeActivity extends AppCompatActivity {

    EditText nameEditText, emailEditText, positionEditText, salaryEditText, departmentEditText, usernameEditText, passwordEditText;
    Button addButton;

    FirebaseDatabase database;
    DatabaseReference employeesRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_employee);

        // Initialize Firebase
        database = FirebaseDatabase.getInstance();
        employeesRef = database.getReference("employees");

        // Find views
        nameEditText = findViewById(R.id.name);
        emailEditText = findViewById(R.id.email);
        positionEditText = findViewById(R.id.position);
        salaryEditText = findViewById(R.id.salary);
        departmentEditText = findViewById(R.id.department);
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        addButton = findViewById(R.id.add);

        // Set onClickListener for the Add button
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get data from the input fields
                String name = nameEditText.getText().toString();
                String email = emailEditText.getText().toString();
                String position = positionEditText.getText().toString();
                String salary = salaryEditText.getText().toString();
                String department = departmentEditText.getText().toString();
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // Validate inputs
                if (name.isEmpty() || email.isEmpty() || position.isEmpty() || salary.isEmpty() || department.isEmpty() || username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(AddEmployeeActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Create a new employee object
                Employee newEmployee = new Employee(name, email, position, Integer.parseInt(salary), department, username, password);

                // Save the employee data into Firebase Realtime Database, Firebase will auto-generate the employeeId
                employeesRef.push().setValue(newEmployee);

                // Show success message
                Toast.makeText(AddEmployeeActivity.this, "Employee added successfully", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Employee class to hold employee data
    public static class Employee {
        String name;
        String email;
        String position;
        int salary;
        String department;
        String username;
        String password;

        // Constructor to initialize the employee data
        public Employee(String name, String email, String position, int salary, String department, String username, String password) {
            this.name = name;
            this.email = email;
            this.position = position;
            this.salary = salary;
            this.department = department;
            this.username = username;
            this.password = password;
        }
    }
}
