package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class LeaveApprovalActivity extends AppCompatActivity {

    TextView leaveRequestTextView;
    Button approveButton, rejectButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leave_approval);

        leaveRequestTextView = findViewById(R.id.leaveRequestTextView);
        approveButton = findViewById(R.id.approveButton);
        rejectButton = findViewById(R.id.rejectButton);

        // Placeholder text for leave requests
        leaveRequestTextView.setText("Leave Request:\nEmployee: John Doe\nReason: Sick Leave");

        approveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                leaveRequestTextView.setText("Leave Approved for John Doe");
            }
        });

        rejectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                leaveRequestTextView.setText("Leave Rejected for John Doe");
            }
        });
    }
}
