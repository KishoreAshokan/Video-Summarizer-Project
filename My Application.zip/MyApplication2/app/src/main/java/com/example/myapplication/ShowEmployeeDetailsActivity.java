package com.example.myapplication;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ShowEmployeeDetailsActivity extends AppCompatActivity {

    private EditText employeeIdEditText;
    private Button fetchButton;
    private TextView employeeDetailsTextView;
    private ProgressBar progressBar;

    private FirebaseDatabase database;
    private DatabaseReference employeesRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_employee_details);

        // Initialize UI components
        employeeIdEditText = findViewById(R.id.employeeIdEditText);
        fetchButton = findViewById(R.id.fetchButton);
        employeeDetailsTextView = findViewById(R.id.employeeDetailsTextView);
        progressBar = findViewById(R.id.progressBar);

        // Initialize Firebase
        database = FirebaseDatabase.getInstance();
        employeesRef = database.getReference("employees");

        // Set up fetch button click listener
        fetchButton.setOnClickListener(v -> {
            String employeeId = employeeIdEditText.getText().toString().trim();

            if (employeeId.isEmpty()) {
                Toast.makeText(ShowEmployeeDetailsActivity.this, "Please enter Employee ID", Toast.LENGTH_SHORT).show();
                return;
            }

            // Show the progress bar while loading data
            progressBar.setVisibility(ProgressBar.VISIBLE);

            // Fetch employee details based on the entered ID
            fetchEmployeeDetails(employeeId);
        });
    }

    private void fetchEmployeeDetails(final String employeeId) {
        // Log the employee ID to ensure it's being passed correctly
        Log.d("EmployeeDetails", "Fetching details for Employee ID: " + employeeId);

        // Fetch employee details using the entered employee ID
        employeesRef.child(employeeId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Log the fetched data for debugging
                    Log.d("EmployeeDetails", "Data fetched for ID: " + employeeId);

                    // Fetch individual employee's details
                    String name = dataSnapshot.child("name").getValue(String.class);
                    String email = dataSnapshot.child("email").getValue(String.class);
                    String position = dataSnapshot.child("position").getValue(String.class);
                    String salaryStr = dataSnapshot.child("salary").getValue(String.class);
                    String department = dataSnapshot.child("department").getValue(String.class);
                    String username = dataSnapshot.child("username").getValue(String.class);

                    // Handle salary conversion from String to Integer safely
                    int salary = 0;
                    try {
                        salary = Integer.parseInt(salaryStr);
                    } catch (NumberFormatException e) {
                        Log.e("EmployeeDetails", "Invalid salary format for " + name);
                    }

                    // Build the details string to display
                    StringBuilder employeeDetails = new StringBuilder();
                    employeeDetails.append("ID: ").append(employeeId).append("\n")
                            .append("Name: ").append(name).append("\n")
                            .append("Email: ").append(email).append("\n")
                            .append("Position: ").append(position).append("\n")
                            .append("Salary: ").append(salary).append("\n")
                            .append("Department: ").append(department).append("\n")
                            .append("Username: ").append(username).append("\n");

                    // Hide the progress bar and display employee details
                    progressBar.setVisibility(ProgressBar.GONE);
                    employeeDetailsTextView.setText(employeeDetails.toString());
                } else {
                    // Handle case where employeeId does not exist
                    Log.d("EmployeeDetails", "No data found for ID: " + employeeId);
                    progressBar.setVisibility(ProgressBar.GONE);
                    Toast.makeText(ShowEmployeeDetailsActivity.this, "No employee found with this ID", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Hide the progress bar if the operation fails
                progressBar.setVisibility(ProgressBar.GONE);
                // Show a toast if fetching data fails
                Log.e("FirebaseError", "Failed to load employee details for ID: " + employeeId, databaseError.toException());
                Toast.makeText(ShowEmployeeDetailsActivity.this, "Failed to load employee details", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
