package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class FireEmployeeActivity extends AppCompatActivity {

    EditText employeeIdEditText;
    Button fireEmployeeButton;
    TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fire_employee);

        employeeIdEditText = findViewById(R.id.employeeIdEditText);
        fireEmployeeButton = findViewById(R.id.fireEmployeeButton);
        resultTextView = findViewById(R.id.resultTextView);

        fireEmployeeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String employeeId = employeeIdEditText.getText().toString();
                if (!employeeId.isEmpty()) {
                    // Placeholder for firing employee
                    resultTextView.setText("Employee with ID " + employeeId + " has been fired.");
                } else {
                    resultTextView.setText("Please enter an employee ID.");
                }
            }
        });
    }
}
