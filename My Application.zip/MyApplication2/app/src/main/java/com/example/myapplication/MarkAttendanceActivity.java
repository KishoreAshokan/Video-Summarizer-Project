package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MarkAttendanceActivity extends AppCompatActivity {

    EditText idEditText, nameEditText, latitudeEditText, longitudeEditText;
    TextView dateTextView;
    Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mark_attendance);

        idEditText = findViewById(R.id.idEditText);
        nameEditText = findViewById(R.id.nameEditText);
        latitudeEditText = findViewById(R.id.latitudeEditText);
        longitudeEditText = findViewById(R.id.longitudeEditText);
        dateTextView = findViewById(R.id.dateTextView);
        saveButton = findViewById(R.id.saveButton);

        // Logic to save attendance (e.g., Toast for now)
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = idEditText.getText().toString();
                String name = nameEditText.getText().toString();
                String latitude = latitudeEditText.getText().toString();
                String longitude = longitudeEditText.getText().toString();
                String date = dateTextView.getText().toString();

                if (id.isEmpty() || name.isEmpty() || latitude.isEmpty() || longitude.isEmpty()) {
                    Toast.makeText(MarkAttendanceActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                } else {
                    // You can save these details to your database here
                    Toast.makeText(MarkAttendanceActivity.this, "Attendance marked for " + name, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
